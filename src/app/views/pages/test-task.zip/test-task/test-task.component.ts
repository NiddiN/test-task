import { Component, OnInit } from '@angular/core';

import {
	SERVICES,
	CUSTOMER_CHARACTERICTISC,
	SALES_MODELS,
	DELIVERY_METHODS,
	PRODUCT_RANGES,
	MONTHLY_REVENUE
} from './fixture';

@Component({
  selector: 'kt-test-task',
  templateUrl: './test-task.component.html',
  styleUrls: ['./test-task.component.scss']
})
export class TestTaskComponent implements OnInit {

	public services = SERVICES;
	public customerCharacteristics = CUSTOMER_CHARACTERICTISC;
	public salesModels = SALES_MODELS;
	public deliveryMethods = DELIVERY_METHODS;
	public productRanges = PRODUCT_RANGES;
	public monthlyRevenue = MONTHLY_REVENUE;

  constructor() { }

  ngOnInit() {
	}
}
